﻿namespace All_Codes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.guna2ContainerControl2 = new Guna.UI2.WinForms.Guna2ContainerControl();
            this.label13 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox10 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox9 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2ContainerControl1 = new Guna.UI2.WinForms.Guna2ContainerControl();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox5 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox6 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox7 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox8 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox4 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox3 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox2 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox1 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2GradientCircleButton2 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.guna2GradientCircleButton1 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.st = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2ContainerControl2.SuspendLayout();
            this.guna2ContainerControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.AnimateWindow = true;
            this.guna2BorderlessForm1.BorderRadius = 50;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.ShadowColor = System.Drawing.Color.White;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(27, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "General";
            // 
            // guna2ContainerControl2
            // 
            this.guna2ContainerControl2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ContainerControl2.BorderColor = System.Drawing.Color.LightGray;
            this.guna2ContainerControl2.BorderRadius = 5;
            this.guna2ContainerControl2.BorderThickness = 1;
            this.guna2ContainerControl2.Controls.Add(this.label13);
            this.guna2ContainerControl2.Controls.Add(this.guna2CustomCheckBox10);
            this.guna2ContainerControl2.Controls.Add(this.label10);
            this.guna2ContainerControl2.Controls.Add(this.guna2CustomCheckBox9);
            this.guna2ContainerControl2.FillColor = System.Drawing.Color.Transparent;
            this.guna2ContainerControl2.Location = new System.Drawing.Point(61, 311);
            this.guna2ContainerControl2.Name = "guna2ContainerControl2";
            this.guna2ContainerControl2.Size = new System.Drawing.Size(287, 41);
            this.guna2ContainerControl2.TabIndex = 4;
            this.guna2ContainerControl2.Text = "guna2ContainerControl2";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(219, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 21);
            this.label13.TabIndex = 5;
            this.label13.Text = "Speed";
            // 
            // guna2CustomCheckBox10
            // 
            this.guna2CustomCheckBox10.Animated = true;
            this.guna2CustomCheckBox10.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox10.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox10.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox10.Location = new System.Drawing.Point(193, 9);
            this.guna2CustomCheckBox10.Name = "guna2CustomCheckBox10";
            this.guna2CustomCheckBox10.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox10.TabIndex = 4;
            this.guna2CustomCheckBox10.Text = "guna2CustomCheckBox10";
            this.guna2CustomCheckBox10.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox10.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox10.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox10.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox10.Click += new System.EventHandler(this.guna2CustomCheckBox10_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(42, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 21);
            this.label10.TabIndex = 3;
            this.label10.Text = "Aimbot Ext";
            // 
            // guna2CustomCheckBox9
            // 
            this.guna2CustomCheckBox9.Animated = true;
            this.guna2CustomCheckBox9.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox9.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox9.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox9.Location = new System.Drawing.Point(16, 10);
            this.guna2CustomCheckBox9.Name = "guna2CustomCheckBox9";
            this.guna2CustomCheckBox9.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox9.TabIndex = 2;
            this.guna2CustomCheckBox9.Text = "guna2CustomCheckBox9";
            this.guna2CustomCheckBox9.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox9.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox9.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox9.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox9.Click += new System.EventHandler(this.guna2CustomCheckBox9_Click);
            // 
            // guna2ContainerControl1
            // 
            this.guna2ContainerControl1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ContainerControl1.BorderColor = System.Drawing.Color.LightGray;
            this.guna2ContainerControl1.BorderRadius = 5;
            this.guna2ContainerControl1.BorderThickness = 1;
            this.guna2ContainerControl1.Controls.Add(this.label6);
            this.guna2ContainerControl1.Controls.Add(this.guna2CustomCheckBox5);
            this.guna2ContainerControl1.Controls.Add(this.label7);
            this.guna2ContainerControl1.Controls.Add(this.guna2CustomCheckBox6);
            this.guna2ContainerControl1.Controls.Add(this.label8);
            this.guna2ContainerControl1.Controls.Add(this.guna2CustomCheckBox7);
            this.guna2ContainerControl1.Controls.Add(this.label9);
            this.guna2ContainerControl1.Controls.Add(this.guna2CustomCheckBox8);
            this.guna2ContainerControl1.Controls.Add(this.label5);
            this.guna2ContainerControl1.Controls.Add(this.guna2CustomCheckBox4);
            this.guna2ContainerControl1.Controls.Add(this.label4);
            this.guna2ContainerControl1.Controls.Add(this.guna2CustomCheckBox3);
            this.guna2ContainerControl1.Controls.Add(this.label3);
            this.guna2ContainerControl1.Controls.Add(this.guna2CustomCheckBox2);
            this.guna2ContainerControl1.Controls.Add(this.label2);
            this.guna2ContainerControl1.Controls.Add(this.guna2CustomCheckBox1);
            this.guna2ContainerControl1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ContainerControl1.Location = new System.Drawing.Point(31, 52);
            this.guna2ContainerControl1.Name = "guna2ContainerControl1";
            this.guna2ContainerControl1.Size = new System.Drawing.Size(356, 234);
            this.guna2ContainerControl1.TabIndex = 3;
            this.guna2ContainerControl1.Text = "guna2ContainerControl1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(265, 185);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 21);
            this.label6.TabIndex = 15;
            this.label6.Text = "Camera";
            // 
            // guna2CustomCheckBox5
            // 
            this.guna2CustomCheckBox5.Animated = true;
            this.guna2CustomCheckBox5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox5.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox5.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox5.Location = new System.Drawing.Point(223, 187);
            this.guna2CustomCheckBox5.Name = "guna2CustomCheckBox5";
            this.guna2CustomCheckBox5.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox5.TabIndex = 14;
            this.guna2CustomCheckBox5.Text = "guna2CustomCheckBox5";
            this.guna2CustomCheckBox5.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox5.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox5.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox5.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox5.Click += new System.EventHandler(this.guna2CustomCheckBox5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(253, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 21);
            this.label7.TabIndex = 13;
            this.label7.Text = "Wall Hack";
            // 
            // guna2CustomCheckBox6
            // 
            this.guna2CustomCheckBox6.Animated = true;
            this.guna2CustomCheckBox6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox6.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox6.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox6.Location = new System.Drawing.Point(223, 137);
            this.guna2CustomCheckBox6.Name = "guna2CustomCheckBox6";
            this.guna2CustomCheckBox6.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox6.TabIndex = 12;
            this.guna2CustomCheckBox6.Text = "guna2CustomCheckBox6";
            this.guna2CustomCheckBox6.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox6.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox6.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox6.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox6.Click += new System.EventHandler(this.guna2CustomCheckBox6_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(261, 82);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 21);
            this.label8.TabIndex = 11;
            this.label8.Text = "Aim Fov";
            // 
            // guna2CustomCheckBox7
            // 
            this.guna2CustomCheckBox7.Animated = true;
            this.guna2CustomCheckBox7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox7.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox7.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox7.Location = new System.Drawing.Point(223, 83);
            this.guna2CustomCheckBox7.Name = "guna2CustomCheckBox7";
            this.guna2CustomCheckBox7.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox7.TabIndex = 10;
            this.guna2CustomCheckBox7.Text = "guna2CustomCheckBox7";
            this.guna2CustomCheckBox7.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox7.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox7.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox7.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox7.Click += new System.EventHandler(this.guna2CustomCheckBox7_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(261, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 21);
            this.label9.TabIndex = 9;
            this.label9.Text = "No Recoil";
            // 
            // guna2CustomCheckBox8
            // 
            this.guna2CustomCheckBox8.Animated = true;
            this.guna2CustomCheckBox8.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox8.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox8.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox8.Location = new System.Drawing.Point(223, 39);
            this.guna2CustomCheckBox8.Name = "guna2CustomCheckBox8";
            this.guna2CustomCheckBox8.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox8.TabIndex = 8;
            this.guna2CustomCheckBox8.Text = "guna2CustomCheckBox8";
            this.guna2CustomCheckBox8.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox8.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox8.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox8.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox8.Click += new System.EventHandler(this.guna2CustomCheckBox8_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(37, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 21);
            this.label5.TabIndex = 7;
            this.label5.Text = "Sniper Switch";
            // 
            // guna2CustomCheckBox4
            // 
            this.guna2CustomCheckBox4.Animated = true;
            this.guna2CustomCheckBox4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox4.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox4.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox4.Location = new System.Drawing.Point(16, 186);
            this.guna2CustomCheckBox4.Name = "guna2CustomCheckBox4";
            this.guna2CustomCheckBox4.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox4.TabIndex = 6;
            this.guna2CustomCheckBox4.Text = "guna2CustomCheckBox4";
            this.guna2CustomCheckBox4.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox4.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox4.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox4.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox4.Click += new System.EventHandler(this.guna2CustomCheckBox4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(42, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 21);
            this.label4.TabIndex = 5;
            this.label4.Text = "Sniper Scope";
            // 
            // guna2CustomCheckBox3
            // 
            this.guna2CustomCheckBox3.Animated = true;
            this.guna2CustomCheckBox3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox3.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox3.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox3.Location = new System.Drawing.Point(16, 137);
            this.guna2CustomCheckBox3.Name = "guna2CustomCheckBox3";
            this.guna2CustomCheckBox3.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox3.TabIndex = 4;
            this.guna2CustomCheckBox3.Text = "guna2CustomCheckBox3";
            this.guna2CustomCheckBox3.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox3.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox3.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox3.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox3.Click += new System.EventHandler(this.guna2CustomCheckBox3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(42, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "Mute Beep";
            // 
            // guna2CustomCheckBox2
            // 
            this.guna2CustomCheckBox2.Animated = true;
            this.guna2CustomCheckBox2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox2.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox2.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox2.Location = new System.Drawing.Point(16, 83);
            this.guna2CustomCheckBox2.Name = "guna2CustomCheckBox2";
            this.guna2CustomCheckBox2.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox2.TabIndex = 2;
            this.guna2CustomCheckBox2.Text = "guna2CustomCheckBox2";
            this.guna2CustomCheckBox2.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox2.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox2.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox2.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox2.Click += new System.EventHandler(this.guna2CustomCheckBox2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(42, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Glitch Fire";
            // 
            // guna2CustomCheckBox1
            // 
            this.guna2CustomCheckBox1.Animated = true;
            this.guna2CustomCheckBox1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox1.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox1.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox1.Location = new System.Drawing.Point(16, 38);
            this.guna2CustomCheckBox1.Name = "guna2CustomCheckBox1";
            this.guna2CustomCheckBox1.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox1.TabIndex = 0;
            this.guna2CustomCheckBox1.Text = "guna2CustomCheckBox1";
            this.guna2CustomCheckBox1.UncheckedState.BorderColor = System.Drawing.Color.LightGray;
            this.guna2CustomCheckBox1.UncheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox1.UncheckedState.BorderThickness = 1;
            this.guna2CustomCheckBox1.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomCheckBox1.Click += new System.EventHandler(this.guna2CustomCheckBox1_Click);
            // 
            // guna2GradientCircleButton2
            // 
            this.guna2GradientCircleButton2.Animated = true;
            this.guna2GradientCircleButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientCircleButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientCircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientCircleButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientCircleButton2.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientCircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2GradientCircleButton2.FillColor = System.Drawing.Color.Salmon;
            this.guna2GradientCircleButton2.FillColor2 = System.Drawing.Color.Salmon;
            this.guna2GradientCircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientCircleButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientCircleButton2.Location = new System.Drawing.Point(411, 12);
            this.guna2GradientCircleButton2.Name = "guna2GradientCircleButton2";
            this.guna2GradientCircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2GradientCircleButton2.Size = new System.Drawing.Size(20, 20);
            this.guna2GradientCircleButton2.TabIndex = 6;
            this.guna2GradientCircleButton2.Click += new System.EventHandler(this.guna2GradientCircleButton2_Click);
            // 
            // guna2GradientCircleButton1
            // 
            this.guna2GradientCircleButton1.Animated = true;
            this.guna2GradientCircleButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientCircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientCircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientCircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientCircleButton1.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientCircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2GradientCircleButton1.FillColor = System.Drawing.Color.PaleGreen;
            this.guna2GradientCircleButton1.FillColor2 = System.Drawing.Color.PaleGreen;
            this.guna2GradientCircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientCircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientCircleButton1.Location = new System.Drawing.Point(385, 12);
            this.guna2GradientCircleButton1.Name = "guna2GradientCircleButton1";
            this.guna2GradientCircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2GradientCircleButton1.Size = new System.Drawing.Size(20, 20);
            this.guna2GradientCircleButton1.TabIndex = 5;
            this.guna2GradientCircleButton1.Click += new System.EventHandler(this.guna2GradientCircleButton1_Click);
            // 
            // st
            // 
            this.st.BackColor = System.Drawing.Color.Transparent;
            this.st.Font = new System.Drawing.Font("Ebrima", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.st.ForeColor = System.Drawing.Color.White;
            this.st.Location = new System.Drawing.Point(31, 398);
            this.st.Name = "st";
            this.st.Size = new System.Drawing.Size(62, 23);
            this.st.TabIndex = 7;
            this.st.Text = "STATUS";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(458, 450);
            this.Controls.Add(this.st);
            this.Controls.Add(this.guna2GradientCircleButton2);
            this.Controls.Add(this.guna2GradientCircleButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guna2ContainerControl2);
            this.Controls.Add(this.guna2ContainerControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.guna2ContainerControl2.ResumeLayout(false);
            this.guna2ContainerControl2.PerformLayout();
            this.guna2ContainerControl1.ResumeLayout(false);
            this.guna2ContainerControl1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ContainerControl guna2ContainerControl2;
        private System.Windows.Forms.Label label13;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox10;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox9;
        private Guna.UI2.WinForms.Guna2ContainerControl guna2ContainerControl1;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox5;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox6;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox7;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox8;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox4;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox3;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox2;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel st;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton2;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton1;
    }
}

